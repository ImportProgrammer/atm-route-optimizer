"""
Aplicación principal de la API para el sistema de optimización de cajeros.

Este módulo configura y ejecuta la API REST utilizando FastAPI, definiendo
middlewares, configuración general y conectando todos los endpoints.
"""